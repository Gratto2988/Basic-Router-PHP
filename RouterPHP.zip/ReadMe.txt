------------------------------
|---Router for PHP---|
------------------------------

This is a basic example of a Router that used utilizes the URI.

The Router is used to direct through web pages using the URI for Efficient navigation.