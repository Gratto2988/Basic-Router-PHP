<?php
$uri = trim($_SERVER['REQUEST_URI'],'/');
$request = $_SERVER['REQUEST_METHOD'];

class Router{

	protected $route = [

		'GET' => [],

		'POST' => []

	];

	public function get($uri, $route){

		$this->route['GET'][$uri] = $route;
	}

	public function post($uri, $route){

		$this->route['POST'][$uri] = $route;
	}


	public function direct($uri, $request)
	{
		
		if(array_key_exists($uri , $this->route[$request])){
			return $this->route[$request][$uri];
		}
	
		throw new Exception('There is something wrong'); 
	}
}

$route = new Router;

$route->get('','view/index.view.php');

$route->post('welcome', 'view/welcome.view.php');

require $route->direct($uri, $request);

