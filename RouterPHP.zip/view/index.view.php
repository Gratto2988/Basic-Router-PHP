<?php

echo "hello World";
?>

<form action="welcome" method="POST">
	Name: <input type="text" name="name"><br>
<input type="submit">
